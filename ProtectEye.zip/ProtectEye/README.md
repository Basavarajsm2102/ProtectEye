# ProtectEye
A project built to detect the distance of user from the camera and provide a warning when it is leass than safe distance
